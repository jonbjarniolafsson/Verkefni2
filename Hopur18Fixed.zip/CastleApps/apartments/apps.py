from django.apps import AppConfig


class ApartmentsConfig(AppConfig):
    name = 'apartments'
