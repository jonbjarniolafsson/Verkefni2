create function delrech() returns void
    language sql
as
$$
DELETE FROM rechnung AS r WHERE r.rnr NOT IN (SELECT b.rnr FROM bestellung AS b WHERE rnr IS NOT NULL)
$$;

alter function delrech() owner to eryfjzyp;

